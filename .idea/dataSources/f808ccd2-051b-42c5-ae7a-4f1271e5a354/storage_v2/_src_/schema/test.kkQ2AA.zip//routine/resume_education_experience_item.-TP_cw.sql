create
  definer = root@localhost procedure resume_education_experience_item(IN education_time_start varchar(10),
                                                                      IN education_time_end varchar(10),
                                                                      IN school_name varchar(15), IN major varchar(15),
                                                                      IN education_level varchar(2),
                                                                      IN major_desc varchar(500)) comment '教育经历'
begin
    select education_time_start|'-'|education_time_end|'          '|school_name|'           '|major|'           '|education_level;
    select '专业描述：'|major_desc;
    select '-------------------------------------------------';
  end;

