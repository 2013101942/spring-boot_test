create
  definer = root@localhost procedure resume_skill_train(IN train_time_start varchar(10), IN train_time_end varchar(10),
                                                        IN train_target varchar(15), IN train_organ varchar(15),
                                                        IN train_addr varchar(5),
                                                        IN train_desc varchar(500)) comment '技能特长-- 培训经历'
begin
    select train_time_start|'-'|train_time_end|'      '|train_target|'       '|train_organ|'(地点：'|train_addr|')';
    select '培训描述：'|train_desc;
  end;

