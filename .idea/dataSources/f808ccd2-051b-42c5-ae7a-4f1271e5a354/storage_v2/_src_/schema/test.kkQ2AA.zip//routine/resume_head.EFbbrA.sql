create
  definer = root@localhost procedure resume_head(IN user_name varchar(4), IN city varchar(5), IN job_age int,
                                                 IN sex varchar(1), IN age int, IN birthday varchar(10),
                                                 IN looking_job tinyint(1), IN e_mail varchar(20),
                                                 IN phone_num varchar(11), IN household_addr varchar(5),
                                                 IN marriage_state tinyint(1),
                                                 IN league_member tinyint(1)) comment '简历头部'
BEGIN
    declare look_str varchar(10) default '目前正在找工作';
    declare marriage_str varchar(2) default '未婚';
    declare league_str varchar(5) default '共青团员';
    if looking_job = false then
      set look_str = '已找到工作';
    end if;
    if marriage_state = true then
      set marriage_str = '已婚';
    end if;
    if league_member = false then
      set league_str = '群众';
    end if;
    select user_name as '姓名';
    select city as '现居住',concat(job_age,'年') as '工作经验',sex as '性别',concat(age,'岁') as '年龄',concat(birthday) as '出生日期',look_str as '是否在找工作';
    select e_mail as '邮箱',phone_num as '电话';
    select household_addr as '户口/国籍',marriage_str as '婚姻状态',league_str as '政治面貌';
  END;

