create
  definer = root@localhost procedure resume_education_condition_duty(IN duty_time_start varchar(10),
                                                                     IN duty_time_end varchar(10),
                                                                     IN duty_name varchar(10),
                                                                     IN duty_desc varchar(200)) comment '在校情况-- 校内职务'
begin
    select concat(duty_time_start,'-',duty_time_end) as '时间',duty_name as '名称',duty_desc as '职务描述';
  end;

