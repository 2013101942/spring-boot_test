create
  definer = root@localhost procedure my_resume()
begin
    select user_name as '姓名',
           city as '现居住城市',
           job_age as '工作经验',
           sex as '性别',
           age as '年龄',
           birthday as '出生日期',
           e_mail as '邮箱',
           phone_num as '联系方式',
           income_by_year as '目前年收入',
           salary as '期望薪资',
           addr as '地点',
           position as '职位',
           tags as '个人标签',
           self_evaluation as '自我评价',
           arrive_time as '到岗时间',
           job_type as '工作类型'
        from table_yuqiang;
     update table_yuqiang set age = 18 where user_name = '余强';
    select user_name as '姓名',
           city as '现居住城市',
           job_age as '工作经验',
           sex as '性别',
           age as '年龄',
           birthday as '出生日期',
           e_mail as '邮箱',
           phone_num as '联系方式',
           income_by_year as '目前年收入',
           salary as '期望薪资',
           addr as '地点',
           position as '职位',
           tags as '个人标签',
           self_evaluation as '自我评价',
           arrive_time as '到岗时间',
           job_type as '工作类型'
    from table_yuqiang;
    delete from table_yuqiang where user_name = '余强';
    select user_name as '姓名',
           city as '现居住城市',
           job_age as '工作经验',
           sex as '性别',
           age as '年龄',
           birthday as '出生日期',
           e_mail as '邮箱',
           phone_num as '联系方式',
           income_by_year as '目前年收入',
           salary as '期望薪资',
           addr as '地点',
           position as '职位',
           tags as '个人标签',
           self_evaluation as '自我评价',
           arrive_time as '到岗时间',
           job_type as '工作类型'
    from table_yuqiang;
  end;

