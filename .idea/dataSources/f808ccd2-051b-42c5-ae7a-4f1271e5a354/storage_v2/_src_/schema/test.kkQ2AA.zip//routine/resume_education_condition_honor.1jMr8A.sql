create
  definer = root@localhost procedure resume_education_condition_honor(IN honor_time varchar(10),
                                                                      IN honor_name varchar(30),
                                                                      IN honor_level varchar(2)) comment '在校情况-- 校内荣誉'
begin
    select honor_time as '时间',honor_name as '荣誉名称',honor_level as '级别';
  end;

