create
  definer = root@localhost procedure resume_education_condition(IN honor_time varchar(10), IN honor_name varchar(30),
                                                                IN honor_level varchar(2)) comment '在校情况-- 校内荣誉'
begin
    select concat(honor_time,'         ',honor_name,'          ',honor_level);
  end;

