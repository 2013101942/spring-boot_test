create
  definer = root@localhost procedure resume_job_experience_item(IN job_time_start varchar(10),
                                                                IN job_time_end varchar(10),
                                                                IN company_name varchar(15),
                                                                IN job_position varchar(20),
                                                                IN company_desc varchar(150),
                                                                IN job_desc varchar(700)) comment '工作经验'
begin
    select concat(job_time_start,'-',job_time_end) as '时间',company_name as '公司',company_desc as '公司描述',job_position as '职位',job_desc as '工作描述';
  end;

