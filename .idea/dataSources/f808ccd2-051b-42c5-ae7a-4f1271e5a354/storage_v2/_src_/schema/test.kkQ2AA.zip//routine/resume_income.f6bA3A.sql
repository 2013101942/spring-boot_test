create
  definer = root@localhost procedure resume_income(IN total_salary int, IN base_salary int, IN subsidy int) comment '目前年收入（单位：万元）'
begin
    select concat(total_salary,'万元（包含基本工资、补贴、奖金、股权收益等）') as '目前年收入', concat(base_salary,'万元') as '基本工资',concat(subsidy,'万元') as '补贴/津贴';
  end;

