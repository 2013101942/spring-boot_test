create
  definer = root@localhost procedure resume_skill_train(IN train_time_start varchar(10), IN train_time_end varchar(10),
                                                        IN train_target varchar(15), IN train_organ varchar(15),
                                                        IN train_addr varchar(5),
                                                        IN train_desc varchar(700)) comment '技能特长-- 培训经历'
begin
    select concat(train_time_start,'-',train_time_end) as '时间',train_target as '培训课程',train_organ as '地点',train_desc as '培训描述';
  end;

