create
  definer = root@localhost procedure resume_skill_item(IN skill_name varchar(20), IN skill_degree varchar(5)) comment '技能特长-- 技能/语言'
begin
    select skill_name as '技能名称',skill_degree as '掌握程度';
  end;

