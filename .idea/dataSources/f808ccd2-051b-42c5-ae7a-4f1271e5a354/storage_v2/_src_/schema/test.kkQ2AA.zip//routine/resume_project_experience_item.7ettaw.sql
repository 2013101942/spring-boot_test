create
  definer = root@localhost procedure resume_project_experience_item(IN project_time_start varchar(10),
                                                                    IN project_time_end varchar(10),
                                                                    IN project_name varchar(30),
                                                                    IN project_desc varchar(800),
                                                                    IN duty_desc varchar(100)) comment '项目经验'
begin
    select project_time_start|'-'|project_time_end|'          '|project_name;
    select '项目描述：'|project_desc;
    select '责任描述：'|duty_desc;
    select '-------------------------------------------------';
  end;

