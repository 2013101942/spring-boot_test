create
  definer = root@localhost procedure resume_skill_certificate(IN certificate_time varchar(10),
                                                              IN certificate_name varchar(15),
                                                              IN certificate_score int) comment '技能特长-- 证书'
begin
    select certificate_time as '时间',certificate_name as '证书名称',certificate_score as '分数';
  end;

