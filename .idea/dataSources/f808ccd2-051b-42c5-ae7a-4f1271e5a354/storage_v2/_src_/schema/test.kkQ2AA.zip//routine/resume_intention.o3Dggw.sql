create
  definer = root@localhost procedure resume_intention(IN intention_salary_start float(1, 1),
                                                      IN intention_salary_end float(1, 1), IN intention_addr varchar(5),
                                                      IN intention_position varchar(20), IN trade varchar(15),
                                                      IN mytags varchar(200), IN self_evaluation varchar(500),
                                                      IN arrival_time varchar(10),
                                                      IN job_type varchar(5)) comment '求职意向(薪资单位：万元)'
begin
    select '求职意向';
    select concat((intention_salary_start*10000),'-',(intention_salary_end*10000),'元/月') as '期望薪资',intention_addr as '地点',intention_position as '职能/职位',trade as '行业';
    select mytags as '个人标签';
    select self_evaluation as '自我评价';
    select arrival_time as '到岗时间',job_type as '工作类型';
  end;

