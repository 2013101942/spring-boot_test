create
  definer = root@localhost procedure resume_education_experience_item(IN education_time_start varchar(10),
                                                                      IN education_time_end varchar(10),
                                                                      IN school_name varchar(15), IN major varchar(15),
                                                                      IN education_level varchar(2),
                                                                      IN major_desc varchar(800)) comment '教育经历'
begin
    select concat(education_time_start,'-',education_time_end) as '时间',school_name as '学校名称',major as '专业',education_level as '学历',major_desc as '专业描述';
  end;

