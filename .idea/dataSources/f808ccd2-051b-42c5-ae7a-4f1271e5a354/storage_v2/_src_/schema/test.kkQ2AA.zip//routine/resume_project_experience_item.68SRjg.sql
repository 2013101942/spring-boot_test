create
  definer = root@localhost procedure resume_project_experience_item(IN project_time_start varchar(10),
                                                                    IN project_time_end varchar(10),
                                                                    IN project_name varchar(30),
                                                                    IN project_desc varchar(1800),
                                                                    IN duty_desc varchar(200)) comment '项目经验'
begin
    select concat(project_time_start,'-',project_time_end) as '时间',project_name as '项目名称',project_desc as '项目描述',duty_desc as '责任描述';
  end;

