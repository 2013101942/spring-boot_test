create
  definer = root@localhost procedure resume_add_info(IN add_name varchar(30), IN add_link varchar(50),
                                                     IN add_desc varchar(500)) comment '附加信息'
begin
    select add_name as '附件名称',add_link as '附件链接',add_desc as '附件描述';
  end;

